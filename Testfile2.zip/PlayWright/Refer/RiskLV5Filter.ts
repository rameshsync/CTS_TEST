import { test, expect, chromium, Page } from '@playwright/test';
import { POManager } from '../../../shared/pages/POManager';
import { mockPath, urls } from '../../../shared/api/urls/urls';
test.describe(
  'INS-40165: Work Mgmt - Submission and Risks Views - Optional Fields - Default View, Filters & Add Filters',
  () => {
    test.beforeEach(async ({ page }) => {
      const poManager = new POManager(page);
      const pageUtils = poManager.getPageUtils();
      const riskTestData = poManager.getRiskTestData();
      /*Mocking submission test data and redirecting to the UWWB application */
      await page.route(`${urls.riskListMockData}`, (route) =>
        route.fulfill({
          path: `${mockPath.riskListViewMockData}`,
        }),
      );
      await pageUtils.goto(`${urls.risk}`);
      await pageUtils.ensureSpinnerLoaderInvisible(5000);
      await expect(page, 'Title should be - uwwb-portal').toHaveTitle(
        riskTestData.uwwbTitle,
      );
    });

    test('@PRIORITY_2 @TEAM_ALL @PRODUCT_WORK_MGMT INS-40165_TC02_AC04_AC05_AC06_AC08_Maximum 5 filters_Risk_List_USML Team', async ({
      page,
    }) => {
      const poManager = new POManager(page);
      const pageUtils = poManager.getPageUtils();
      const riskPage = poManager.getRiskPage();
      const riskTestData = poManager.getRiskTestData();
      const listFlowUtils = poManager.getListFlowUtils();

      /*Default Risk is displayed in the Risk list view,*/
      await expect(
        await pageUtils.getSizeOfListOfElements(await riskPage.tableGridDetail),
        'List View should be visible with Risk records',
      ).toBeGreaterThan(0);

      let listViewGridData: any[] = await listFlowUtils.addGridDataToObject();
      const defaultSubmCount = listViewGridData.length;

      /*2 filters available by default:
        1.Date
        2.Assignee: Current user should be applied in the assignee filter by default if not changed
        'Show On Hold' toggle should be off by default */
      await expect(
        await pageUtils.getAvailFilters(),
        'Available Filters should be ' + riskTestData.defaultFilters,
      ).toEqual(riskTestData.defaultFilters);

      await pageUtils.datePicker(
        riskPage.dateFilter,
        riskTestData.riskDate.date5,
      );
      await pageUtils.selectDropDown(
        riskPage.assigneeFilter,
        riskTestData.assigneeTooltip,
      );

      /*User should be able to add the filters. 
        The UI placement of the 'Add Filter' icon should be shifted right and New filter should be added in the column header */
      /*Additional filters: 1. Last Updated 2. Status 3. Transaction type */
      await pageUtils.addRequiredFilter(
        riskTestData.optFilterslist.lastUpdated,
      );
      await pageUtils.datePicker(
        riskPage.lastUpdatedFilter,
        riskTestData.riskDate.date4,
      );
      await expect(
        await pageUtils.getAvailFilters(),
        'Available Filters should be ' + riskTestData.availFiltersWithL,
      ).toEqual(riskTestData.availFiltersWithL);

      await pageUtils.addRequiredFilter(riskTestData.optFilterslist.status);
      await pageUtils.selectDropDown(
        riskPage.statusFilter,
        riskTestData.riskStatus.Rating,
      );
      await expect(
        await pageUtils.getAvailFilters(),
        'Available Filters should be ' + riskTestData.availFiltersWithLS,
      ).toEqual(riskTestData.availFiltersWithLS);

      await pageUtils.addRequiredFilter(
        riskTestData.optFilterslist.transactionType,
      );
      await pageUtils.selectDropDown(
        riskPage.transactionTypeFilter,
        riskTestData.riskTransactionType.New,
      );
      await expect(
        await pageUtils.getAvailFilters(),
        'Available Filters should be ' + riskTestData.availFiltersWithLST,
      ).toEqual(riskTestData.availFiltersWithLST);

      /*Add Filter' icon will be not be visible as there are 5 filters present in the UI and 
        additional/optional filters can be removed by clicking on the 'X' icon, next to the filter */
      await expect(riskPage.addFilter).toHaveCount(0);
      await expect(riskPage.removeFilter).toHaveCount(3);

      /*Remove one filter: Last Updated
        Default filters: 'Date' and 'Assignee' can't be removed
        'Add Filter' icon should be enabled to add new filter*/
      await pageUtils.removeFilter(riskTestData.optFilterslist.lastUpdated);

      await expect(
        await pageUtils.removeFilter(riskTestData.defFilterslist.date),
      ).toBeFalsy();
      await expect(
        await pageUtils.removeFilter(riskTestData.defFilterslist.assignee),
      ).toBeFalsy();
      await expect(riskPage.addFilter).toHaveCount(1);

      /*Add filter: Priority 
        Add Filter' icon will be not be visible as there are 5 filters present in the UI and 
        additional/optional filters can be removed by clicking on the 'X' icon, next to the filter*/
      await pageUtils.addRequiredFilter(riskTestData.optFilterslist.priority);
      await expect(
        await pageUtils.getAvailFilters(),
        'Available Filters should be ' + riskTestData.availFiltersWithSTP,
      ).toEqual(riskTestData.availFiltersWithSTP);

      await expect(riskPage.addFilter).toHaveCount(0);
      await expect(riskPage.removeFilter).toHaveCount(3);

      /*Filters added in the list view should persist on the risk WF view */
      await riskPage.workFlowView.click();

      await expect(
        await pageUtils.getAvailFilters(),
        'Available Filters should be ' + riskTestData.availFiltersWithSTP,
      ).toEqual(riskTestData.availFiltersWithSTP);

      await expect(riskPage.addFilter).toHaveCount(0);
      await expect(riskPage.removeFilter).toHaveCount(3);

      /*Navigate back to Risk List view and refresh the session
        On refresh, risk list view will be displaying the default risk and the default filters.
        And all additional/optional filters added will be removed */
      await riskPage.listView.click();

      await pageUtils.reload();

      await expect(
        await pageUtils.getAvailFilters(),
        'Available Filters should be ' + riskTestData.defaultFilters,
      ).toEqual(riskTestData.defaultFilters);

      listViewGridData = await listFlowUtils.addGridDataToObject();
      await expect(listViewGridData.length).toEqual(defaultSubmCount);
    });
  },
);
