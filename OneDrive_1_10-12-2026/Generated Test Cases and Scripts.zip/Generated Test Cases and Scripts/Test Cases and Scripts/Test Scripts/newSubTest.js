const { AccountPage } = require('../page_factory/AccountPage');
const { NewSubPage } = require('../page_factory/NewSubPage');
const { Given, When, Then, Before, AfterAll, setDefaultTimeout } = require('@cucumber/cucumber');
const { expect } = require('@playwright/test');
const { chromium } = require('playwright');
const { LoginPage } = require('../page_factory/LoginPage');

// Initialize page objects
let loginPage;
let accountPage;
let newSubPage;
let startTime, endTime;
let browser, context, page;

Before(async function () {
  setDefaultTimeout(120000); // Set default timeout to 120 seconds
  startTime = new Date();
  console.log("Launching browser...");
  browser = await chromium.launch({ headless: false });
  context = await browser.newContext({ viewport: null, incognito: true }); // Open browser in incognito mode
  page = await context.newPage();
  loginPage = new LoginPage(page);
  accountPage = new AccountPage(page);
  newSubPage = new NewSubPage(page);
});

AfterAll(async function () {
  if (browser) {
    await browser.close(); // ensure the browser is closed if it was initialized
  } else {
    console.log("Browser object is undefined, skipping close operation.");
  }
  endTime = new Date(); // End time measurement
  const executionTime = endTime - startTime;
  console.log(`Total execution time: ${executionTime}ms`);
});

Given('the user launches the Guidewire application URL and is on the login page of the policycenter application', 
    { timeout: 90000 }, // Increase timeout to 90 seconds
    async () => {
      console.log("Navigating to URL...");
      await loginPage.goToLoginPage('http://in-pnq-coe31:5180/pc/PolicyCenter.do');
      await page.waitForLoadState('networkidle', { timeout: 60000 }); // Ensure page fully loads
      
      const timeout = 10000;
      try {
        await page.waitForSelector('input[name="Login-LoginScreen-LoginDV-username"]', { timeout });
        await page.waitForSelector('input[name="Login-LoginScreen-LoginDV-password"]', { timeout });
        await page.waitForSelector('div[id="Login-LoginScreen-LoginDV-submit"]', { timeout });
      } catch (error) {
        console.error("Element not found within timeout, taking screenshot and printing page content...");
        await page.screenshot({ path: 'error_screenshot.png' });
        console.log(await page.content());
        throw error;
      }
  });
  

When('the User enters the username and password.', async () => {
  console.log("Filling username...");
  await loginPage.enterUsername('su'); // Replace with actual username
  console.log("Filling password...");
  await loginPage.enterPassword('gw');  // Replace with actual password
  await page.waitForLoadState('networkidle', { timeout: 60000 }); // 60 seconds
});

When('User clicks on the Log In button.', async () => {
  console.log("Clicking submit...");
  await loginPage.clickLogInButton();
  await page.waitForLoadState('networkidle', { timeout: 60000 }); // 60 seconds
});

When('the user clicks on the "Account" option', async function () {
  await accountPage.clickAccountOption();
  await page.waitForLoadState('networkidle', { timeout: 60000 }); // 60 seconds
});

Then('the "Account Summary" page should be displayed', { timeout: 60000 }, async function () {
    await page.waitForLoadState('networkidle', { timeout: 60000 }); // Ensures full page load
    await accountPage.verifyAccountSumPage();
  });
  
  

  When('the user clicks on the "New Submission" option from the Account Summary page', 
    { timeout: 120000 }, // Increase timeout to 120 seconds
    async function () {
      await page.waitForLoadState('domcontentloaded', { timeout: 30000 }); // Wait for DOM to load
      await page.waitForLoadState('networkidle', { timeout: 60000 }); // Wait for network to stabilize
    
      await accountPage.clickNewSubmissionOption();
  });
Then('the "New Submissions" page should be displayed', async function () {
  await newSubPage.verifyNewSubmissionPage();
  await page.waitForLoadState('networkidle', { timeout: 60000 }); // 60 seconds
});

When('the user enters the required fields on the "New Submissions" page and selects:', async function (dataTable) {
  await newSubPage.fillNewSubmissionDetails();
  await page.waitForLoadState('networkidle', { timeout: 60000 }); // 60 seconds
});

Then('the selected options should be displayed, and the user should be directed to the "Offerings" page', async function () {
  await newSubPage.verifyOfferingsPage();
  await page.waitForLoadState('networkidle', { timeout: 60000 }); // 60 seconds
});

When('the user selects the "Offering - Special Risk" and clicks on "Next"', async function () {
  await newSubPage.selectOffering();
  await page.waitForLoadState('networkidle', { timeout: 60000 }); // 60 seconds
});

Then('the offering should be selected, and the user should be directed to the "Qualification" screen', async function () {
  await newSubPage.verifyQualificationPage();
  await page.waitForLoadState('networkidle', { timeout: 60000 }); // 60 seconds
});

When('the user answers the qualification questions with "Yes" or "No" and clicks on "Next"', async function () {
  await newSubPage.answerQualificationQuestions();
  await page.waitForLoadState('networkidle', { timeout: 60000 }); // 60 seconds
});

Then('the user should be directed to the "Policy Info" screen.', async function () {
  await newSubPage.verifyPolicyInfoPage();
  await page.waitForLoadState('networkidle', { timeout: 60000 }); // 60 seconds
});