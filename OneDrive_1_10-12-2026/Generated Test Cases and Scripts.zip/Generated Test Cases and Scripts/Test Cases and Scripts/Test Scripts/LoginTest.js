const { Given, When, Then, Before, AfterAll } = require('@cucumber/cucumber');
const { expect } = require('@playwright/test');
const { chromium } = require('playwright');
// const { LoginPage } = require('../page_factory/LoginPage');
// Initialize page objects
let loginPage;
let startTime, endTime;
let browser, context, page;

Before(async function () {
    startTime = new Date();
    browser = await chromium.launch({ headless: false });
    context = await browser.newContext();
    page = await context.newPage();
    loginPage = new LoginPage(page);
});

  AfterAll(async function () {
    if (browser) {
        await browser.close(); // ensure the browser is closed if it was initialized
    } else {
        console.log("Browser object is undefined, skipping close operation.");
    }
    endTime = new Date(); // End time measurement
    const executionTime = endTime - startTime;
    console.log(`Total execution time: ${executionTime}ms`);
});


Given('the user launches the Guidewire application URL and is on the login page of the policycenter application', async () => {
    await loginPage.goToLoginPage('http://in-pnq-coe31:5180/pc/PolicyCenter.do'); // Replace with the actual URL of the login page
});


When('the User enters the username and password.', async () => {

    await loginPage.enterUsername('su'); // Replace with actual username
    await loginPage.enterPassword('gw');  // Replace with actual password

});

When('User clicks on the Log In button.', async () => {
    await loginPage.clickLogInButton();
    await page.waitForLoadState('networkidle');
  });

  When('User clicks on the dropdown on the Account tab', async function () {
      // Write code here that turns the phrase above into concrete actions
       await loginPage.clickOnAccountTab();
    });


  When ('User clicks on the New Account option', async function(){
    await loginPage.clickOnNewAccount();
  });

  Then('the Enter Account Information screen should open successfully', async function () {
    await expect(this.page.locator('text=Enter Account Information')).toBeVisible();
  });
  
  When('the user enters the company name {string} in the search field', async function (companyName) {
    await this.page.fill('#AccountSearch\\:AccountSearchScreen\\:AccountSearchDV\\:GlobalContactNameInputSet\\:Name-inputEl', companyName);
  });
  
  When('the user clicks on the {string} button', async function (buttonText) {
    await this.page.click(`button:has-text("${buttonText}")`);
  });
  
  Then('the search results should display the matching account in the list with company name {string}', async function (companyName) {
    await expect(this.page.locator(`text=${companyName}`)).toBeVisible();
  });





