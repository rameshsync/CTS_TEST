class NewSubPage {
  constructor(page) {
    this.page = page;
    this.verifyNewSub = page.locator("//div[contains(@class, 'gw-TitleBar--title') and contains(text(), 'New Submission')]");
    this.productSelect = page.locator("//div[@id='NewSubmission-NewSubmissionScreen-ProductOffersDV-ProductSelectionLV-4-addSubmission']");
    this.verifyOfferingPage = page.locator("//div[@class='gw-TitleBar--title' and contains(., 'Offerings')]");
    this.offeringDropdown = page.locator("//select[@name='SubmissionWizard-OfferingScreen-OfferingSelection']");
    this.offeringSelect = page.locator("//option[@value='Special Risk']");
    this.nextButton = page.locator("//div[@class='gw-label' and text()='Next'])[1]");
    this.verifyQualiPage = page.locator("//div[contains(@class, 'gw-TitleBar--title') and contains(text(), 'Qualification')]");
    this.radioButton1 = page.locator("//input[@id='SubmissionWizard-SubmissionWizard_PreQualificationScreen-PreQualQuestionSetsDV-QuestionSetsDV-0-QuestionSetLV-0-QuestionModalInput-BooleanRadioInput_NoPost_1']");
    this.radioButton2 = page.locator("//input[@id='SubmissionWizard-SubmissionWizard_PreQualificationScreen-PreQualQuestionSetsDV-QuestionSetsDV-0-QuestionSetLV-1-QuestionModalInput-BooleanRadioInput_NoPost_1']");
    this.radioButton3 = page.locator("//input[@id='SubmissionWizard-SubmissionWizard_PreQualificationScreen-PreQualQuestionSetsDV-QuestionSetsDV-0-QuestionSetLV-2-QuestionModalInput-BooleanRadioInput_NoPost_1']");
    this.radioButton4 = page.locator("//input[@id='SubmissionWizard-SubmissionWizard_PreQualificationScreen-PreQualQuestionSetsDV-QuestionSetsDV-0-QuestionSetLV-3-QuestionModalInput-BooleanRadioInput_NoPost_1']");
    this.nextOpt = page.locator("//div[contains(@class, 'gw-action--inner')]//div[contains(@class, 'gw-label') and text()='Next']");
    this.verifyPolicyScreen = page.locator("//div[contains(@class, 'gw-TitleBar--title') and contains(text(), 'Policy Info')]");
    this.policyInfoFields = {
      dateQuoteNeeded: page.locator("//div[@id='SubmissionWizard-LOBWizardStepGroup-SubmissionWizard_PolicyInfoScreen-SubmissionWizard_PolicyInfoDV-DateQuoteNeeded_dateIcon']"),
      dateselect: page.locator("//td[contains(@class, 'gw-datePicker--today-cell') and @data-day='5' and @data-month='1' and @data-year='2025']"),
      estimatedPremium: page.locator("//input[@name='SubmissionWizard-LOBWizardStepGroup-SubmissionWizard_PolicyInfoScreen-SubmissionWizard_PolicyInfoDV-estimatedPremiumInput']"),
      FEIN: page.locator("//input[@name='SubmissionWizard-LOBWizardStepGroup-SubmissionWizard_PolicyInfoScreen-SubmissionWizard_PolicyInfoDV-AccountInfoInputSet-PolicyOfficialIDInputSet-OfficialIDDV_Input']"),
      industryCode: page.locator("//input[@name='SubmissionWizard-LOBWizardStepGroup-SubmissionWizard_PolicyInfoScreen-SubmissionWizard_PolicyInfoDV-AccountInfoInputSet-IndustryCode']")
    };
    this.addButton = page.locator('button:has-text("Add")');
    this.locationNameInput = page.locator('#LocationName');
    this.classCodeInput = page.locator('#ClassCode');
    this.basisInput = page.locator('#Basis');
    this.quoteButton = page.locator('button:has-text("Quote")');
    this.bindOptionsButton = page.locator('button:has-text("Bind Options")');
    this.issuePolicySelect = page.locator('#IssuePolicy');
    this.okButton = page.locator('button:has-text("OK")');
  }

  locationCheckBox(selector) {
    return this.page.locator(selector);
  }

  clickNext(selector) {
    return this.page.locator(selector).click();
  }

  async verifyNewSubmissionPage() {
    await this.verifyNewSub.waitFor({ state: 'visible' });
    const isVisible = await this.verifyNewSub.isVisible();
    if (!isVisible) {
      throw new Error('New Submission page is not visible');
    }
  }

  async fillNewSubmissionDetails(product) {
    await this.productSelect.selectOption(product);
  }

  async verifyOfferingsPage() {
    await this.verifyOfferingPage.waitFor({ state: 'visible' });
    const isVisible = await this.verifyOfferingPage.isVisible();
    if (!isVisible) {
      throw new Error('Offerings page is not visible');
    }
  }

  async selectOffering(offering) {
    await this.offeringDropdown.click();
    await this.offeringSelect.selectOption(offering);
    await this.nextButton.click();
  }

  async verifyQualifcationPage() {
    await this.verifyQualiPage.waitFor({ state: 'visible' });
    const isVisible = await this.verifyQualiPage.isVisible();
    if (!isVisible) {
      throw new Error('Qualification page is not visible');
    }
  }

  async answerQualificationQuestions(answer) {
    await this.radioButton1.click();
    await this.radioButton2.click();
    await this.radioButton3.click();
    await this.radioButton4.click();
    await this.nextOpt.click();
  }

  async verifyPolicyInfoPage() {
    await this.verifyNewSub.waitFor({ state: 'visible' });
    const isVisible = await this.verifyPolicyScreen.isVisible();
    if (!isVisible) {
      throw new Error('Policy  page is not visible');
    }
  }

  // async fillPolicyInfo(fields) {
  //   for (const [key, value] of Object.entries(fields)) {
  //     await this.policyInfoFields[key].fill(value);
  //   }
  // }

  // async addExposure(locationName, classCode, basis) {
  //   await this.addButton.click();
  //   await this.locationNameInput.fill(locationName);
  //   await this.classCodeInput.fill(classCode);
  //   await this.basisInput.fill(basis);
  //   await this.quoteButton.click();
  // }

  // async bindPolicy() {
  //   await this.bindOptionsButton.click();
  //   await this.issuePolicySelect.selectOption('Issue Policy');
  //   await this.okButton.click();
  // }
}

module.exports = { NewSubPage };