const { expect } = require('@playwright/test');

class AccountPage {
  constructor(page) {
    this.page = page;
    this.accountOption = page.locator("//*[@id='TabBar-AccountTab']/div[1]/div[2]");
    this.verifyAccSumPage = page.locator("//div[contains(@class, 'gw-TitleBar--title') and contains(text(), 'Account Summary')]");
    this.newSubmissionOption = page.locator("(//div[@class='gw-action--inner gw-hasDivider gw-focus']//div[@class='gw-label'][normalize-space()='New Submission'])");
  }

  async clickAccountOption() {
    await this.waitForElement(this.accountOption);
    await this.accountOption.click();
  }

  async verifyAccountSumPage() {
    try {
      console.log("Waiting for Account Summary page...");
      await this.verifyAccSumPage.waitFor({ state: 'visible', timeout: 60000 });
      console.log("Account Summary page is visible.");
    } catch (error) {
      console.error("Account Summary page did not load within the timeout.");
      throw new Error('Account Summary page is not visible');
    }
  }

  async clickNewSubmissionOption() {
    try {
      console.log("Waiting for New Submission option...");
      await this.newSubmissionOption.waitFor({ state: 'visible', timeout: 30000 });
      console.log("New Submission option is visible.");
      await this.newSubmissionOption.click();
    } catch (error) {
      console.error("New Submission option did not load within the timeout.");
      throw new Error('New Submission option is not visible');
    }
  }

  async waitForElement(locator) {
    try {
      console.log(`Waiting for element: ${locator}`);
      await locator.waitFor({ state: 'attached', timeout: 30000 }); // Increased timeout to 30s
      await locator.waitFor({ state: 'visible', timeout: 20000 }); // Increased timeout to 20s
      console.log('Element is attached and visible.');
    } catch (e) {
      console.error('Element is not available within the timeout period.');
      throw e;
    }
  }
}

module.exports = { AccountPage };