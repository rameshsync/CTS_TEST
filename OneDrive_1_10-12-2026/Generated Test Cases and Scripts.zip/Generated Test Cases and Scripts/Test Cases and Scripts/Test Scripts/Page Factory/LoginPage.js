const { expect } = require('@playwright/test');

class LoginPage {
    constructor(page) {
        this.page = page;
        this.username = page.locator('//input[@name="Login-LoginScreen-LoginDV-username"]');
        this.password = page.locator('//input[@name="Login-LoginScreen-LoginDV-password"]');
        this.logInButton = page.locator('//div[@class="gw-label" and text()="Log In"]');
    }

    async goToLoginPage(url) {
        await this.page.goto(url);
        await this.page.waitForLoadState('networkidle'); // Wait for the page to load completely
        console.log('Login page loaded successfully.');
    }

    async enterUsername(username) {
        await this.waitForElement(this.username);
        await this.username.fill(username);
        console.log('Username entered successfully.');
    }

    async enterPassword(password) {
        await this.waitForElement(this.password);
        await this.password.fill(password);
        console.log('Password entered successfully.');
    }

    async clickLogInButton() {
        await this.waitForElement(this.logInButton);
        await this.logInButton.click();
    }

    async waitForElement(locator) {
        try {
            await locator.waitFor({ state: 'visible', timeout: 7000 });
            console.log('Element is visible.');
        } catch (e) {
            console.log('Element is not visible within the timeout period.');
            throw e;
        }
    }
}

module.exports = { LoginPage };