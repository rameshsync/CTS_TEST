const { Page } = require('@playwright/test');

class AccountInfoPage {
    constructor(page) {
        this.page = page;
    }

    async verifyEnterAccInfoPage() {
        await this.page.waitForSelector("//div[@class='gw-TitleBar--title' and text()='Enter Account Information']");
    }

    async enterCompanyname(companyName) {
        await this.page.fill("//input[@name='NewAccount-NewAccountScreen-NewAccountSearchDV-GlobalContactNameInputSet-Name']", companyName);
    }

    async clickOnSearch() {
        await this.page.click("//div[@id='NewAccount-NewAccountScreen-NewAccountSearchDV-SearchAndResetInputSet-SearchLinksInputSet-Search']");
    }

    async createNewAccOpt() {
        await this.page.click("//div[@class='gw-ListView--UI--title' and text()='Search Results']");
    }

    async selectCompanyOpt() {
        await this.page.click("//div[@class='gw-label' and text()='Company']");
    }

    async selectFromAdressBookOpt() {
        await this.page.click("//div[@class='gw-label' and text()='From Address Book']");
    }
}

module.exports = { AccountInfoPage };
//==============================================================================================

    
