const { Given, When, Then } = require('@cucumber/cucumber');
const { expect } = require('@playwright/test');
const { AddressBookPage } = require('../pages/AddressBookPage');

let addressBookPage;

When('User navigates to the Address Book page', async function () {
    addressBookPage = new AddressBookPage(this.page);
    await addressBookPage.openAddressBook();
});

When('User adds a new address with details {string}, {string}, {string}', async function (name, street, city) {
    await addressBookPage.addNewAddress(name, street, city);
});

Then('The new address should be saved successfully', async function () {
    await addressBookPage.verifyAddressSaved();
});

When('User searches for an address with name {string}', async function (name) {
    await addressBookPage.searchAddress(name);
});

Then('The search results should display the matching address', async function () {
    await addressBookPage.verifySearchResults();
});

When('the user enters the required details like name and ZIP Code', async function () {
    await addressBookPage.enterZipCode('12345'); // Replace with dynamic ZIP Code input
});

When('the user clicks on the Search button', async function () {
    await addressBookPage.clickSearchButton();
});

Then('matching address details should populate from the Address book', async function () {
    await addressBookPage.verifyMatchingAddressDetails();
});

When('the user enters the required details like name and invalid ZIP Code', async function () {
    await addressBookPage.enterZipCode('00000'); // Replace with an invalid ZIP Code
});

Then('the search results should display a message "The search returned zero results."', async function () {
    await addressBookPage.verifyNoResultsMessage(); // Implement verification in AddressBookPage
});
