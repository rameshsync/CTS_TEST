const { Page } = require('@playwright/test');

class HomePage {
    constructor(page) {
        this.page = page;
        this.accountTab = page.locator('//div[@id="TabBar-AccountTab"]//div[@class="gw-icon gw-icon--expand"]');
        this.newAccountOption = page.locator('//div[@id="TabBar-AccountTab-AccountTab_NewAccount"]//div[@class="gw-action--inner gw-hasDivider"]');
        this.dashboardText = page.locator('//h1[text()="Dashboard"]');  // Replace with actual locator for the homepage
    }

    async waitForHomePage() {
        await this.dashboardText.waitFor({ state: 'visible', timeout: 3000 });
        console.log('Home page is loaded.');
    }

    async clickAccountTab() {
        await this.accountTab.waitFor({ state: 'visible', timeout: 5000 });
        await this.accountTab.click();
        console.log('Clicked on the Account tab on the homepage.');
    }

    async clickNewAccountOption() {
        await this.newAccountOption.waitFor({ state: 'visible', timeout: 3000 });
        await this.newAccountOption.click();
        console.log('Clicked on the New Account option on the homepage.');
    }
}

module.exports = { HomePage };
