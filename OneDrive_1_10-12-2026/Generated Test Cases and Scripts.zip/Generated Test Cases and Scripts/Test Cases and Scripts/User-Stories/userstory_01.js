	US01- Account Creation
	"Description":
	As a PolicyCenter user, should be able to create account"
	
	AC01 – Ability to create new account from Account Tab – New Account or From Action menu – Create new account
	GIVEN the user does have the ‘Account Creation’ permission
	When the user clicks dropdown on ‘Account’ tab
	THEN the ‘New Account’ should be visible 
	
	AC02 – Ability to search for a company name by providing exact name
	GIVEN the user on ‘Enter Account Information’ screen
	When the user enters exact name of company and click on ‘Search’
	THEN the ‘Search Results’ should display matching account name
	
	AC03 – Ability to retrieve address from Address book
	GIVEN the user on ‘Create Account’
	When the user enters name 
	AND enters zipcode clicks on search
	THEN the matching address details should populate
	
	AC04 – Ability to save account information and generate a account number
	GIVEN the user on ‘Create Account’
	WHEN the user enters name , address, ‘Organization’, ‘Producer code’ 
	AND click on ‘Update’
	THEN the ‘Account no’ should be displayed on ‘Account Summary’ screen

	


	
