
	US03 – Issue Policy Change
	"Description:
    As a PolicyCenter user, should be able to perform, policy change so that I can amend the changes for the policy and commit policy details( Example – Premium change) "
	
	AC01 – Initiate a policy change
	GIVEN an policy exists
	When user click on ‘change in policy’ via actions menu
	AND user enters all mandatory fields( Example – Add exposure, update coverage fields)
	THEN Policy change screen should display 
	
	AC02 – Policy change coverage updates
	GIVEN an policy change has been initiated
	WHEN user opens coverage screen  
	THEN the user able to edit the coverage details
	
	AC03 – Creating history event for policy change
	GIVEN an policy transaction
	WHEN user completes a policy change 
	THEN History event should created

	







	


	