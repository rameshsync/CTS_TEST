	US02 – New Submission & Issue policy 
	"Description:
    As a PolicyCenter user, should be able to create account"
	
	AC01 – New submission
	GIVEN the user does have the existing account
	WHEN the user clicks on Actions – New submission
	AND select ‘Base state’ , ‘Product – General Liability’, ‘Offering – Special risk ’ 
	AND clicks on ‘Next’ and enters mandatory fields on ‘ Policy info’ screen
	AND add a exposure details, clicks ‘Quote’
	THEN premium should calculated and display on quote screen
	
	AC02 – View summary of insured, Coverages and policy information before quoting
	GIVEN the user does have the existing account
	WHEN the user clicks on Actions – New submission
	AND select ‘Base state’ , ‘Product – General Liability’, ‘Offering – Special risk ’ 
	AND clicks on ‘Next’ and enters mandatory fields on ‘ Policy info’ screen
	AND validate insured, Coverages and policy information
	THEN Insured, Coverages and policy information should display 
	
	AC03 – Creating history event for policy issuance
	GIVEN an policy transaction
	WHEN user completes a policy issuance
	THEN History event should created.

	

	
