Feature: Account Creation and Search Functionality

  # Background:
  #   Given the user launches the Guidewire application URL and is on the login page of the policycenter application.
  
    
  @Positive
  Scenario: Create an account from the Account tab dropdown menu
      Given the user launches the Guidewire application URL and is on the login page of the policycenter application
      When  the User enters the username and password.
      And  User clicks on the Log In button.
      When User clicks on the dropdown on the Account tab
      When User clicks on the New Account option
      #Then the Enter Account Information screen should open successfully.

