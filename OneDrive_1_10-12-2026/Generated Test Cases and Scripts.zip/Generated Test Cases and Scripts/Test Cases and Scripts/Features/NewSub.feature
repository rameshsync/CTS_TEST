Feature: New Submission in PolicyCenter
  
  @Positive
  Scenario: Verify the user can create a new submission in the PolicyCenter Application
    Given the user launches the Guidewire application URL and is on the login page of the policycenter application
    When  the User enters the username and password.
    And  User clicks on the Log In button.
    When the user clicks on the "Account" option
    Then the "Account Summary" page should be displayed
    When the user clicks on the "New Submission" option from the Account Summary page
   Then the "New Submissions" page should be displayed
   When the user enters the required fields on the "New Submissions" page and selects:
      | Base State         | California        |
      | Product            | General Liability |
    Then the selected options should be displayed, and the user should be directed to the "Offerings" page
  #   When the user selects the "Offering - Special Risk" and clicks on "Next"
  #   Then the offering should be selected, and the user should be directed to the "Qualification" screen
  #   When the user answers the qualification questions with "Yes" or "No" and clicks on "Next"
  #   Then the user should be directed to the "Policy Info" screen
  #   When the user enters the mandatory fields on the "Policy Info" screen, such as:
  #     | Field                  | Value                            |
  #     | Date Quote Needed      | MM/dd/yyyy (e.g., 01/15/2024)   |
  #     | Estimated Premium      | 1500                            |
  #     | Primary Named Insured  | January                         |
  #     | Phone                  | 360-576-5672                    |
  #     | Policy Address         | 8902 NE 5th Ave, Vancouver, WA  |
  #     | County                 | Clark                           |
  #     | Address Type           | Business                        |
  #     | Organization           | Agent One                       |
  #   Then the policy details should be saved successfully
  #   When the user navigates to the "Exposure" screen
  #   Then the "Exposure" screen should be displayed
  #   When the user clicks on "Add" and enters:
  #     | Location Name | ABC   |
  #     | Class Code    | 123   |
  #     | Basis         | 456   |
  #   And clicks on "Quote"
  #   Then the premium should be calculated and displayed on the quote screen
  #   When the user verifies the total premium, taxes, and total cost
  #   Then the premium, taxes, and total cost should be displayed correctly
  #   When the user clicks on "Bind Options," selects "Issue Policy," and clicks on "OK"
  #   Then the policy should be issued successfully, and the confirmation message should be displayed on the "Submission Bound" screen.

    
  #  @Negative Scenario
  # Scenario: Verify the user cannot create a new submission with invalid Credentials in the PolicyCenter Application
  #   When the user enters the username "invalid" and password "invalid"
  #   And the user clicks on the "Login" button
  #   Then the user should see an error message "Invalid credentials. Please try again."

  #  @Negative Scenario
  # Scenario: Verify the user cannot create a new submission with missing fields in the PolicyCenter Application
  #   When the user enters the username "su" and password "gw"
  #   And the user clicks on the "Login" button
  #   Then the user should be logged in successfully and be on the homepage of the Guidewire PolicyCenter application.
  #   When the user clicks on the "Account" option
  #   Then the "Account Summary" page should be displayed
  #   When the user clicks on the "New Submission" option from the Account Summary page
  #   Then the "New Submissions" page should be displayed
  #   When the user clicks on "Next" without entering any mandatory fields
  #   Then the user should see an error message "Please fill in all required fields."

  #   @Negative Scenario
  # Scenario: Verify the user cannot create a new submission with invalid data in the PolicyCenter Application
  #   When the user enters the username "su" and password "gw"
  #   And the user clicks on the "Login" button
  #   Then the user should be logged in successfully and be on the homepage of the Guidewire PolicyCenter application.
  #   When the user clicks on the "Account" option
  #   Then the "Account Summary" page should be displayed
  #   When the user clicks on the "New Submission" option from the Account Summary page
  #   Then the "New Submissions" page should be displayed
  #   When the user enters invalid data in the mandatory fields
  #   Then the user should see an error message "Invalid data. Please correct the fields."


  #   @Positive Scenario
  #   Scenario: Verify the user can create a new submission with valid data in the PolicyCenter Application
  #   When the user enters the username "su" and password "gw"
  #   And the user clicks on the "Login" button
  #   Then the user should be logged in successfully and be on the homepage of the Guidewire PolicyCenter application.
  #   When the user clicks on the "Account" option
  #   Then the "Account Summary" page should be displayed
  #   When the user clicks on the "New Submission" option from the Account Summary page
  #   Then the "New Submissions" page should be displayed
  #   When the user enters the required fields on the "New Submissions" page and selects:
  #     | Base State         | California        |
  #     | Product            | General Liability |
  #   Then the selected options should be displayed, and the user should be directed to the "Offerings" page
  #   When the user selects the "Offering - Special Risk" and clicks on "Next"
  #   Then the offering should be selected, and the user should be directed to the "Qualification" screen
  #   When the user answers the qualification questions with "Yes" or "No" and clicks on "Next"
  #   Then the user should be directed to the "Policy Info" screen
  #   When the user enters the mandatory fields on the "Policy Info" screen, such as:
  #     | Field                  | Value                            |
  #     | Date Quote Needed      | MM/dd/yyyy (e.g., 01/15/2024)   |
  #     | Estimated Premium      | 1500                            |
  #     | Primary Named Insured  | January                         |
  #     | Phone                  | 360-576-5672                    |
  #     | Policy Address         | 8902 NE 5th Ave, Vancouver, WA  |
  #     | County                 | Clark                           |
  #     | Address Type           | Business                        |
  #     | Organization           | Agent One                       |
  #   Then the policy details should be saved successfully
  #   When the user navigates to the "Exposure" screen
  #   Then the "Exposure" screen should be displayed
  #   When the user clicks on "Add" and enters:
  #     | Location Name | ABC   |
  #     | Class Code    | 123   |
  #     | Basis         | 456   |
  #   And clicks on "Quote"
  #   Then the premium should be calculated and displayed on the quote screen
  #   When the user verifies the total premium, taxes, and total cost
  #   Then the premium, taxes, and total cost should be displayed correctly
  #   When the user clicks on "Bind Options," selects "Issue Policy," and clicks on "OK"
  #   Then the policy should be issued successfully, and the confirmation message should be displayed on the "Submission Bound" screen.