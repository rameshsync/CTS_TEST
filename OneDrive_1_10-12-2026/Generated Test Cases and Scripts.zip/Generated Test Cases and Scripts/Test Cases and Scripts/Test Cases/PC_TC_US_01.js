


//================================================================================================================================//

Test Case ID: TC-001
Summary: Verify the user is able to create an account from Account tab in Guidewire PolicyCenter application.
Acceptance Criteria ID: AC01
Labels: Functional, High Priority
Description: The user should be able to create an account from the account tab dropdown in the Guidewire PolicyCenter application.
Prerequisites: The user is on the login page of the guidewire PolicyCenter application and must have a valid account.
Step-1
Action: Launch the Guidewire PolicyCenter application URL.
Data: URL: http://in-pnq-coe31:5180/pc/PolicyCenter.do
Expected Result: The Guidewire PolicyCenter application should open successfully.
Step-2
Action: Enter the username and password in the respective fields.
Data: Username: "su", Password: "gw"
Expected Result: The username and password should be entered successfully.
Step-3
Action: Click on the 'Login' button.
Data: NA
Expected Result: The user should be logged in successfully.
Step-4
Action: Click on the dropdown on the 'Account' tab 
Data: NA
Expected Result: The 'New Account' option should be visible.
Step-5
Action: Click on the 'New Account' option.
Data: NA
Expected Result: The 'Enter Account Information' screen should open successfully.
Test Type: Functional
Components: Account Tab, New Account Option
Test Case Type: Positive
Product: Guidewire PolicyCenter
Platform: Web
Sprint: Sprint 1
Priority: High

//================================================================================================================================//
Test Case ID: TC-002
Summary: Verify the user is able to create an account from Actions menu tab in Guidewire PolicyCenter application.
Acceptance Criteria ID: AC01
Labels: Functional, High Priority
Description: The user should be able to create an account from the Actions menu tab in the Guidewire PolicyCenter application.
Prerequisites: The user is on the login page of the guidewire PolicyCenter application and must have a valid account.
Step-1
Action: Launch the Guidewire PolicyCenter application URL.
Data: URL: http://in-pnq-coe31:5180/pc/PolicyCenter.do
Expected Result: The Guidewire PolicyCenter application should open successfully.
Step-2
Action: Enter the username and password in the respective fields.
Data: Username: "su", Password: "gw"
Expected Result: The username and password should be entered successfully.
Step-3
Action: Click on the 'Login' button.
Data: NA
Expected Result: The user should be logged in successfully.
Step-4
Action: Click on the 'Desktop' option.
Data: NA    
Expected Result: The 'Actions' menu should be visible.
Step-5
Action: Click on the 'Actions' meny.
Data: NA
Expected Result: The 'New Account' option should be visible.
Step-6
Action: Click on the 'New Account' option.
Data: NA
Expected Result: The 'Enter Account Information' screen should open successfully.
Test Type: Functional
Components: Actions Menu, New Account Option
Test Case Type: Positive
Product: Guidewire PolicyCenter
Platform: Web
Sprint: Sprint 1
Priority: High


//================================================================================================================================//
Test Case ID: TC-003
Summary: Verify the user is able to search for a company name by providing the exact name in Guidewire PolicyCenter application.
Acceptance Criteria ID: AC02
Labels: Functional, High Priority
Description: The user should be able to search for a company name by providing the exact name in the 'Enter Account Information' screen.
Prerequisites: The user is on the 'Enter Account Information' screen in the Guidewire PolicyCenter application.
Step-1
Action: Enter the exact name of the company in the search field.
Data: Company Name: ABC Company
Expected Result: The company name should be entered successfully.
Step-2
Action: Click on the 'Search' button.
Data: NA
Expected Result: The 'Search Results' should display the matching account name with company name, acc no, address.
Test Type: Functional
Components: Enter Account Information Screen, Search Button
Test Case Type: Positive
Product: Guidewire PolicyCenter
Platform: Web
Sprint: Sprint 1
Priority: High

//==========================================================================================================================================

Test Case ID: TC-004
Summary: Verify the user is prompted to create a new account if the company name entered does not exist in the Guidewire PolicyCenter application.
Acceptance Criteria ID: AC02
Labels: Functional, High Priority
Description: The user should be prompted to create a new account if the company name entered does not exist in the 'Enter Account Information' screen.
Prerequisites: The user is on the 'Enter Account Information' screen in the Guidewire PolicyCenter application.
Step-1
Action: Enter a non-existing company name in the search field.
Data: Company Name: XYZ Company
Expected Result: The company name should be entered successfully.
Step-2
Action: Click on the 'Search' button.
Data: NA
Expected Result: The 'Search Results' should display a message indicating "The search returned zero results" found and provide an option to create a new account.
Test Type: Functional
Components: Enter Account Information Screen, Search Button
Test Case Type: Positive
Product: Guidewire PolicyCenter
Platform: Web
Sprint: Sprint 1
Priority: High

//================================================================================================================================//

Test Case ID: TC-005
Summary: Verify the user is able to search for a company name with partial match in Guidewire PolicyCenter application.
Acceptance Criteria ID: AC02
Labels: Functional, High Priority
Description: The user should be able to search for a company name by providing a partial name in the 'Enter Account Information' screen.
Prerequisites: The user is on the 'Enter Account Information' screen in the Guidewire PolicyCenter application.
Step-1
Action: Enter a partial name of the company in the search field.
Data: Company Name: ABC
Expected Result: The partial company name should be entered successfully.
Step-2
Action: Click on the 'Search' button.
Data: NA
Expected Result: The 'Search Results' should display all matching account names with the partial company name.
Test Type: Functional
Components: Enter Account Information Screen, Search Button
Test Case Type: Positive
Product: Guidewire PolicyCenter
Platform: Web
Sprint: Sprint 1
Priority: High

//================================================================================================================================//

Test Case ID: TC-006
Summary: Verify the user is able to search for a company name with special characters in Guidewire PolicyCenter application.
Acceptance Criteria ID: AC02
Labels: Functional, High Priority
Description: The user should be able to search for a company name by providing a name with special characters in the 'Enter Account Information' screen.
Prerequisites: The user is on the 'Enter Account Information' screen in the Guidewire PolicyCenter application.
Step-1
Action: Enter a company name with special characters in the search field.
Data: Company Name: ABC & Co.
Expected Result: The company name with special characters should be entered successfully.
Step-2
Action: Click on the 'Search' button.
Data: NA
Expected Result: The 'Search Results' should display the "The search returned zero results".
Test Type: Functional
Components: Enter Account Information Screen, Search Button
Test Case Type: Positive
Product: Guidewire PolicyCenter
Platform: Web
Sprint: Sprint 1
Priority: High

//================================================================================================================================//

Test Case ID: TC-007
Summary: Verify the user is able to search for a company name with numeric characters in Guidewire PolicyCenter application.
Acceptance Criteria ID: AC02
Labels: Functional, High Priority
Description: The user should be able to search for a company name by providing a name with numeric characters in the 'Enter Account Information' screen.
Prerequisites: The user is on the 'Enter Account Information' screen in the Guidewire PolicyCenter application.
Step-1
Action: Enter a company name with numeric characters in the search field.
Data: Company Name: ABC123
Expected Result: The company name with numeric characters should be entered successfully.
Step-2
Action: Click on the 'Search' button.
Data: NA
Expected Result: The 'Search Results' should display "The search returned zero results".
Test Type: Functional
Components: Enter Account Information Screen, Search Button
Test Case Type: Positive
Product: Guidewire PolicyCenter
Platform: Web
Sprint: Sprint 1
Priority: High

//================================================================================================================================//

Test Case ID: TC-008
Summary: Verify the user is displayed an error message when entering an empty company name in Guidewire PolicyCenter application.
Acceptance Criteria ID: AC02
Labels: Functional, High Priority
Description: The user should be displayed an error message when entering an empty company name in the 'Enter Account Information' screen.
Prerequisites: The user is on the 'Enter Account Information' screen in the Guidewire PolicyCenter application.
Step-1
Action: Leave the company name field empty.
Data: Company Name: (empty)
Expected Result: The company name field should be empty.
Step-2
Action: Click on the 'Search' button.
Data: NA
Expected Result: An error message should be displayed "Errors: Please enter enough name information, an official ID, account number, phone number, or producer information. If searching by last name without an exact match, either city and state, or ZIP are required. At least three letters are required for names (five for companies) without exact match.".
Test Type: Functional
Components: Enter Account Information Screen, Search Button
Test Case Type: Negative
Product: Guidewire PolicyCenter
Platform: Web
Sprint: Sprint 1
Priority: High

//================================================================================================================================//

Test Case ID: TC-009
Summary: Verify the user is able to retrieve address from the Address book in Guidewire PolicyCenter application.
Acceptance Criteria ID: AC03
Labels: Functional, High Priority
Description: The user should be able to retrieve the address from the Address book in the 'Create Account' screen.
Prerequisites: The user is on the 'Create Account' screen in the Guidewire PolicyCenter application.
Step-1
Action: The user enters the required details like name and ZIP Code.
Data: 
    - Name: Capgemini
    - ZIP Code: 41105-7000
Expected Result: The required details should be entered successfully.
Step-2
Action: Click on the 'Search' button.
Data: NA
Expected Result: The matching address details should populate from the Address book.
Test Type: Functional
Components: Create Account Screen, Search Button
Test Case Type: Positive
Product: Guidewire PolicyCenter
Platform: Web
Sprint: Sprint 1
Priority: High

//================================================================================================================================//

Test Case ID: TC-010
Summary: Verify the user is able to retrieve address from the Address book with partial name match in Guidewire PolicyCenter application.
Acceptance Criteria ID: AC03
Labels: Functional, High Priority
Description: The user should be able to retrieve the address from the Address book by providing a partial name in the 'Create Account' screen.
Prerequisites: The user is on the 'Create Account' screen in the Guidewire PolicyCenter application.
Step-1
Action: The user enters the required details like partial name and ZIP Code.
Data: 
    - Name: Cap
    - ZIP Code: 41105-7000
Expected Result: The required details should be entered successfully.
Step-2
Action: Click on the 'Search' button.
Data: NA
Expected Result: The matching address details should populate from the Address book.
Test Type: Functional
Components: Create Account Screen, Search Button
Test Case Type: Positive
Product: Guidewire PolicyCenter
Platform: Web
Sprint: Sprint 1
Priority: High

//================================================================================================================================//

Test Case ID: TC-011
Summary: Verify the user is able to retrieve address from the Address book with numeric characters in the name in Guidewire PolicyCenter application.
Acceptance Criteria ID: AC03
Labels: Functional, High Priority
Description: The user should be able to retrieve the address from the Address book by providing a name with numeric characters in the 'Create Account' screen.
Prerequisites: The user is on the 'Create Account' screen in the Guidewire PolicyCenter application.
Step-1
Action: The user enters the required details like name with numeric characters and ZIP Code.
Data: 
    - Name: Capgemini123
    - ZIP Code: 41105-7000
Expected Result: The required details should be entered successfully.
Step-2
Action: Click on the 'Search' button.
Data: NA
Expected Result: The matching address details should populate from the Address book or an error message should be displayed if no match found.
Test Type: Functional
Components: Create Account Screen, Search Button
Test Case Type: Positive
Product: Guidewire PolicyCenter
Platform: Web
Sprint: Sprint 1
Priority: High

//================================================================================================================================//

Test Case ID: TC-012
Summary: Verify the user is displayed an error message when entering an invalid ZIP Code in Guidewire PolicyCenter application.
Acceptance Criteria ID: AC03
Labels: Functional, High Priority
Description: The user should be displayed an error message when entering an invalid ZIP Code in the 'Create Account' screen.
Prerequisites: The user is on the 'Create Account' screen in the Guidewire PolicyCenter application.
Step-1
Action: The user enters the required details like name and an invalid ZIP Code.
Data: 
    - Name: Capgemini
    - ZIP Code: 123
Expected Result: The required details should be entered successfully.
Step-2
Action: Click on the 'Search' button.
Data: NA
Expected Result: An error message should be displayed indicating that the ZIP Code is invalid.
Test Type: Functional
Components: Create Account Screen, Search Button
Test Case Type: Negative
Product: Guidewire PolicyCenter
Platform: Web
Sprint: Sprint 1
Priority: High

//================================================================================================================================//

Test Case ID: TC-013
Summary: Verify the user is displayed an error message when entering an empty name in Guidewire PolicyCenter application.
Acceptance Criteria ID: AC03
Labels: Functional, High Priority
Description: The user should be displayed an error message when entering an empty name in the 'Create Account' screen.
Prerequisites: The user is on the 'Create Account' screen in the Guidewire PolicyCenter application.
Step-1
Action: The user leaves the name field empty and enters other required details.
Data: 
    - Name: (empty)
    - ZIP Code: 41105-7000
Expected Result: The required details should be entered successfully.
Step-2
Action: Click on the 'Search' button.
Data: NA
Expected Result: An error message should be displayed indicating that the name field cannot be empty.
Test Type: Functional
Components: Create Account Screen, Search Button
Test Case Type: Negative
Product: Guidewire PolicyCenter
Platform: Web
Sprint: Sprint 1
Priority: High

//================================================================================================================================//

Test Case ID: TC-014
Summary: Verify the user is displayed an error message when entering an invalid FEIN in Guidewire PolicyCenter application.
Acceptance Criteria ID: AC03
Labels: Functional, High Priority
Description: The user should be displayed an error message when entering an invalid FEIN in the 'Create Account' screen.
Prerequisites: The user is on the 'Create Account' screen in the Guidewire PolicyCenter application.
Step-1
Action: The user enters the required details like name, ZIP Code, and an invalid FEIN.
Data: 
    - Name: Capgemini
    - ZIP Code: 41105-7000
    - FEIN: 12345
Expected Result: The required details should be entered successfully.
Step-2
Action: Click on the 'Search' button.
Data: NA
Expected Result: An error message should be displayed indicating that the FEIN is invalid.
Test Type: Functional
Components: Create Account Screen, Search Button
Test Case Type: Negative
Product: Guidewire PolicyCenter
Platform: Web
Sprint: Sprint 1
Priority: High

//================================================================================================================================//

Test Case ID: TC-015
Summary: Verify the user is able to save the account information and generate an account number in Guidewire PolicyCenter application.
Acceptance Criteria ID: AC04
Labels: Functional, High Priority
Description: The user should be able to save the account information and generate an account number in Guidewire PolicyCenter application.
Prerequisites: The user is on the 'Create Account' screen in the Guidewire PolicyCenter application.
Step-1
Action: The user enters the required details like name, ZIP Code, and other fields.
Data: 
    - Name: Capgemini
    - ZIP Code: 41105-7000
    - Office Phone: 123-456-7890
    - Fax: 123-456-7891
    - Primary Email: primary@example.com
    - Secondary Email: secondary@example.com
    - Address: 123 Main St
    - Country: USA
    - Address 1: Suite 100
    - Address 2: Building A
    - Address 3: Floor 2
    - City: New York
    - County: New York County
    - State: NY
    - Address Type: Business
    - Description: Main Office
    - Organization Type: Corporation
    - Description of Business: IT Services
    - Official IDs: 123456789
    - FEIN: 12-3456789
    - Account Nickname: Capgemini Main
    - Industry Code: 1234
    - Select Producer: John Doe
    - Organization: Capgemini
Expected Result: The required details should be entered successfully.
Step-2
Action: Click on the 'Update' button.
Data: NA
Expected Result: The account number  information should be displayed successfully on the 'Account Summary' screen.
Test Type: Functional
Components: Create Account Screen, Update Button
Test Case Type: Positive
Product: Guidewire PolicyCenter
Platform: Web
Sprint: Sprint 1
Priority: High

//================================================================================================================================//

Test Case ID: TC-016
Summary: Verify the user is able to save the account information with all mandatory fields filled in Guidewire PolicyCenter application.
Acceptance Criteria ID: AC04
Labels: Functional, High Priority
Description: The user should be able to save the account information with all mandatory fields filled in Guidewire PolicyCenter application.
Prerequisites: The user is on the 'Create Account' screen in the Guidewire PolicyCenter application.
Step-1
Action: The user enters all mandatory details like name, address, organization, and producer code.
Data: 
    - Name: Capgemini
    - Address: 123 Main St
    - Organization: Capgemini
    - Producer Code: 12345
Expected Result: The required details should be entered successfully.
Step-2
Action: Click on the 'Update' button.
Data: NA
Expected Result: The account number information should be displayed successfully on the 'Account Summary' screen.
Test Type: Functional
Components: Create Account Screen, Update Button
Test Case Type: Positive
Product: Guidewire PolicyCenter
Platform: Web
Sprint: Sprint 1
Priority: High

//================================================================================================================================//

Test Case ID: TC-017
Summary: Verify the user is able to save the account information with optional fields filled in Guidewire PolicyCenter application.
Acceptance Criteria ID: AC04
Labels: Functional, High Priority
Description: The user should be able to save the account information with optional fields filled in Guidewire PolicyCenter application.
Prerequisites: The user is on the 'Create Account' screen in the Guidewire PolicyCenter application.
Step-1
Action: The user enters all mandatory and optional details like name, address, organization, producer code, and additional information.
Data: 
    - Name: Capgemini
    - Address: 123 Main St
    - Organization: Capgemini
    - Producer Code: 12345
    - Office Phone: 123-456-7890
    - Fax: 123-456-7891
    - Primary Email: primary@example.com
    - Secondary Email: secondary@example.com
    - Address 1: Suite 100
    - Address 2: Building A
    - Address 3: Floor 2
    - City: New York
    - County: New York County
    - State: NY
    - Address Type: Business
    - Description: Main Office
    - Organization Type: Corporation
    - Description of Business: IT Services
    - Official IDs: 123456789
    - FEIN: 12-3456789
    - Account Nickname: Capgemini Main
    - Industry Code: 1234
    - Select Producer: John Doe
Expected Result: The required details should be entered successfully.
Step-2
Action: Click on the 'Update' button.
Data: NA
Expected Result: The account number information should be displayed successfully on the 'Account Summary' screen.
Test Type: Functional
Components: Create Account Screen, Update Button
Test Case Type: Positive
Product: Guidewire PolicyCenter
Platform: Web
Sprint: Sprint 1
Priority: High

//================================================================================================================================//

Test Case ID: TC-018
Summary: Verify the user is displayed an error message when trying to save the account information with missing mandatory fields in Guidewire PolicyCenter application.
Acceptance Criteria ID: AC04
Labels: Functional, High Priority
Description: The user should be displayed an error message when trying to save the account information with missing mandatory fields in Guidewire PolicyCenter application.
Prerequisites: The user is on the 'Create Account' screen in the Guidewire PolicyCenter application.
Step-1
Action: The user enters incomplete details like missing name, address, organization, or producer code.
Data: 
    - Name: (empty)
    - Address: 123 Main St
    - Organization: Capgemini
    - Producer Code: 12345
Expected Result: The required details should be entered successfully.
Step-2
Action: Click on the 'Update' button.
Data: NA
Expected Result: An error message should be displayed indicating that mandatory fields are missing.
Test Type: Functional
Components: Create Account Screen, Update Button
Test Case Type: Negative
Product: Guidewire PolicyCenter
Platform: Web
Sprint: Sprint 1
Priority: High

//================================================================================================================================//

Test Case ID: TC-019
Summary: Verify the user is displayed an error message when entering invalid data in mandatory fields in Guidewire PolicyCenter application.
Acceptance Criteria ID: AC04
Labels: Functional, High Priority
Description: The user should be displayed an error message when entering invalid data in mandatory fields in Guidewire PolicyCenter application.
Prerequisites: The user is on the 'Create Account' screen in the Guidewire PolicyCenter application.
Step-1
Action: The user enters invalid details like invalid name, address, organization, or producer code.
Data: 
    - Name: 12345
    - Address: 123 Main St
    - Organization: Capgemini
    - Producer Code: ABCDE
Expected Result: The required details should be entered successfully.
Step-2
Action: Click on the 'Update' button.
Data: NA
Expected Result: An error message should be displayed indicating that invalid data has been entered.
Test Type: Functional
Components: Create Account Screen, Update Button
Test Case Type: Negative
Product: Guidewire PolicyCenter
Platform: Web
Sprint: Sprint 1
Priority: High

//================================================================================================================================//

Test Case ID: TC-020
Summary: Verify the user is displayed an error message when entering duplicate account information in Guidewire PolicyCenter application.
Acceptance Criteria ID: AC04
Labels: Functional, High Priority
Description: The user should be displayed an error message when entering duplicate account information in Guidewire PolicyCenter application.
Prerequisites: The user is on the 'Create Account' screen in the Guidewire PolicyCenter application.
Step-1
Action: The user enters duplicate details like name, address, organization, and producer code that already exist in the system.
Data: 
    - Name: Capgemini
    - Address: 123 Main St
    - Organization: Capgemini
    - Producer Code: 12345
Expected Result: The required details should be entered successfully.
Step-2
Action: Click on the 'Update' button.
Data: NA
Expected Result: An error message should be displayed indicating that duplicate account information has been entered.
Test Type: Functional
Components: Create Account Screen, Update Button
Test Case Type: Negative
Product: Guidewire PolicyCenter
Platform: Web
Sprint: Sprint 1
Priority: High

//================================================================================================================================//

Test Case ID: TC-021
Summary: Verify the user is able to save the account information with any special characters in Guidewire PolicyCenter application.
Acceptance Criteria ID: AC04
Labels: Functional, High Priority
Description: The user should be able to save the account information with special characters in Guidewire PolicyCenter application.
Prerequisites: The user is on the 'Create Account' screen in the Guidewire PolicyCenter application.
Step-1
Action: The user enters details with special characters like name, address, organization, and producer code.
Data: 
    - Name: Capgemini & Co.
    - Address: 123 Main St
    - Organization: Capgemini
    - Producer Code: 12345
Expected Result: The required details should be entered successfully.
Step-2
Action: Click on the 'Update' button.
Data: NA
Expected Result: The account number information should be displayed successfully on the 'Account Summary' screen.
Test Type: Functional
Components: Create Account Screen, Update Button
Test Case Type: Positive
Product: Guidewire PolicyCenter
Platform: Web
Sprint: Sprint 1
Priority: High

