//----------------------------------Test Cases----------------------------------

Test Case ID: TC-001
Summary: Verify the ability to create and submit a new submission in PolicyCenter.
Acceptance Criteria ID: AC01
Labels: Functional, Regression, High Priority
Description: This test case verifies that a user can navigate to the Account page, create and submit a new submission, and get a quote for their project in the PolicyCenter application.
Prerequisites: User must have a valid account with username 'su' and password 'gw'.
Steps:
1. Step ID: Step-1
   Action: Navigate to the PolicyCenter application login page.
   Data: URL: https://policycenter-url.com
   Expected Result: Login page is displayed.

2. Step ID: Step-2
   Action: Enter username and password, then click the login button.
   Data: Username: su, Password: gw
   Expected Result: User is redirected to the PolicyCenter homepage.

3. Step ID: Step-3
   Action: Click on the "Account" tab in the navbar.
   Expected Result: User is navigated to the Account page.

4. Step ID: Step-4
   Action: Find and click the New Submission button in the Open Policy Transactions section.
   Expected Result: New Submission form is displayed.

5. Step ID: Step-5
   Action: Fill out the fields under Select producer.
   Data: Organization: Sample Organization, Producer Code: 12345
   Expected Result: Fields are filled out correctly.

6. Step ID: Step-6
   Action: Fill out the fields under product offers.
   Data: Single or Multiple Policies: Single, Quote Type: Standard, Default Base State: CA, Default Effective Date: 2023-01-01
   Expected Result: Fields are filled out correctly.

7. Step ID: Step-7
   Action: Select the given product name, product description, and status from the displayed list.
   Data: Product Name: Sample Product
   Expected Result: Product is selected and offerings page is displayed.

8. Step ID: Step-8
   Action: Select "silver" or "platinum" from the Offering selection dropdown.
   Data: Offering: Silver
   Expected Result: Offering is selected.

9. Step ID: Step-9
   Action: Click yes or no for "Is the customer based in British Columbia?", "Is the customer a member of Partners Alliance?"
   Data: Is the customer based in British Columbia?: Yes, Is the customer a member of Partners Alliance?: No
   Expected Result: Fields are filled out correctly.

10. Step ID: Step-10
    Action: Click next to navigate to the "Qualification" page.
    Expected Result: User is navigated to the Qualification page.

11. Step ID: Step-11
    Action: Click yes or no for all the questions on the Qualification page and click next.
    Data: All questions: Yes
    Expected Result: User is navigated to the Policy Info page.

12. Step ID: Step-12
    Action: Enter required fields on the Policy Info page.
    Data: Data Quote needed: 2023-01-01, Estimated Premium: 1000
    Expected Result: Fields are filled out correctly.

13. Step ID: Step-13
    Action: Add additional named insureds.
    Data: Named Insured Name: John Doe
    Expected Result: Named insured is added.

14. Step ID: Step-14
    Action: Click next to navigate to the Business Owners page.
    Expected Result: User is navigated to the Business Owners page.

15. Step ID: Step-15
    Action: Fill out mandatory fields on the Business Owners page.
    Data: Included Coverages: Coverage A, Additional Coverages: Coverage B, Exclusions & Conditions: Condition A
    Expected Result: Fields are filled out correctly.

16. Step ID: Step-16
    Action: Click next to navigate to the Locations tab.
    Expected Result: User is navigated to the Locations page.

17. Step ID: Step-17
    Action: Add a new location or select an existing location.
    Data: New Location Details: 123 Main St
    Expected Result: Location is added or selected.

18. Step ID: Step-18
    Action: Add additional coverages if required.
    Data: Additional Coverages: Coverage C
    Expected Result: Additional coverages are added.

19. Step ID: Step-19
    Action: Click next to navigate to the Buildings page.
    Expected Result: User is navigated to the Buildings page.

20. Step ID: Step-20
    Action: Add a new building.
    Data: Building Details: Building 1
    Expected Result: Building is added.

21. Step ID: Step-21
    Action: Add additional coverages if required.
    Data: Additional Coverages: Coverage D
    Expected Result: Additional coverages are added.

22. Step ID: Step-22
    Action: Select the new building added.
    Expected Result: Building is selected.

23. Step ID: Step-23
    Action: Click next to navigate to the Modifiers page.
    Expected Result: User is navigated to the Modifiers page.

24. Step ID: Step-24
    Action: Add modifiers.
    Data: Modifiers: Modifier 1
    Expected Result: Modifiers are added.

25. Step ID: Step-25
    Action: Click next to navigate to the Risk Analysis page.
    Expected Result: User is navigated to the Risk Analysis page.

26. Step ID: Step-26
    Action: Add UW issue, contingency, request approval, lock for review.
    Data: UW Issue: Issue 1, Contingency: Contingency 1
    Expected Result: Fields are filled out correctly.

27. Step ID: Step-27
    Action: Click next to navigate to the Policy Review page.
    Expected Result: User is navigated to the Policy Review page.

28. Step ID: Step-28
    Action: Click on "Quote" button.
    Expected Result: Quote details are displayed.

29. Step ID: Step-29
    Action: Click next to navigate to the Forms page.
    Expected Result: User is navigated to the Forms page.

30. Step ID: Step-30
    Action: Click next to navigate to the Payment Page.
    Expected Result: User is navigated to the Payment Page.

31. Step ID: Step-31
    Action: Verify payment details.
    Expected Result: Payment details are displayed.
    Test Type: Functional
    Components: Login Page, Account Page, New Submission Form, Qualification Page, Policy Info Page, Business Owners Page, Locations Page, Buildings Page, Modifiers Page, Risk Analysis Page, Policy Review Page, Forms Page, Payment Page
    Test Case Type: Positive
    Product: PolicyCenter
    Platform: Web
    Sprint: Sprint 1
    Priority: High