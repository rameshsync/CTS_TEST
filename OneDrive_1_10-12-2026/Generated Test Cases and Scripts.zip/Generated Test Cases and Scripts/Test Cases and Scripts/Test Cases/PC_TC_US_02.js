

Test Case ID/ Issue ID: TC-001
Summary: Verify the user can create a new submission in the policycenter.
Acceptance Criteria ID: AC01    
Labels: Smoke, Functional, Regression
Description: The user should be able to create a new submission in the policycenter application.
Prerequisites: The user has valid login credentials.
Steps:
    Step-1
    Action: When the user navigates to the PolicyCenter application URL.
    Data: URL: http://in-pnq-coe31:5180/pc/PolicyCenter.do
    Expected Result: Then the login page is displayed.

    Step-2
    Action: When the user enters the valid username and password.
    Data: Username: su, Password: gw.
    Expected Result: Then the user is logged in successfully.

    Step-3
    Action: When the user navigates to the 'New Submission' option from the Actions menu.
    Data: Submission: New Submission.
    Expected Result: Then the submission page is displayed.

    Step-4
    Action: When the user enters the required fields, selects the 'Base state', from the drop down list ,'Product- General Liability' from the list of products.
    Data:Base state: California, Product: General Liability
    Expected Result: Then the selected options are displayed and is directed to the offerings page.

    Step-5
    Action: When the user selects the 'offering - Special risk' and clicks on 'Next'.
    Data: Offering: Special risk.
    Expected Result: Then the offering is selected and the user is directed to the 'Qualification' screen.

    Step-6
    Action: When the User selects "Yes" or "No" for the qualification questions and clicks on next.
    Data: Yes/No
    Expected Result: Then the user is directed to the 'Policy info' screen.
    
    Step-7
    Action: When the user enters mandatory fields on the 'Policy info' screen like Data Quote needed and Estimated Premium.
    Data: 
        - Date Quote Needed: MM/dd/yyyy 
        - Estimated Premium: 
        - Primary Named Insured: January
        - Phone: 360-576-5672
        - Policy Address: 8902 NE 5th Ave, Vancouver, WA 98665
        - County: 
        - Address Type: Business
        - Address Description: 
        - Official IDs: 
        - FEIN: 
        - Industry Code: 
        - Business and Operations: 
        - Year Business Started: 
        - Description of business and operations: 
        - Organization Type: 
        - Additional Named Insureds: 
        - Name: 
        - Relationship to Primary Named Insured: 
        - Industry Code: 
        - Policy Details: 
        - Term Type: 
        - Term Number: 
        - Effective Date: 
        - Expiration Date: 
        - Written Date: 
        - Rate as of Date: 
        - Base State: 
        - Affinity Group: 
        - Name: 
        - Producer of Record: 
        - Organization: Agent One
        - Producer Code: 
        - Underwriting Companies: 
    Expected Result: Then the policy details are saved successfully.
    
    Step-8
    Action: When the user Navigates to the exposure screen 
    Data: Exposure details
    Expected Result: Then the exposure screen is displayed.
    
    Step-9
    Action: When the user clicks on Add and enter location name, class code, Basis, as mentioned in UI and click "Quote"
    Data: Location Name: ABC, Class Code: 123, Basis: 456
    Expected Result: Then the premium is calculated and displayed on the quote screen.
    
    Step-10
    Action: When the user verifies Total premium, Taxes & Total cost
    Data: -
    Expected Result: Then premium, taxes, and total cost are displayed correctly.
    
    Step-11
    Action: When the user Clicks on Bind options and select Issue Policy and then click on OK
    Note: Any soft warning message - just ignore
    Data: -
    Expected Result: Then the policy is issued successfully and the confirmation message is displayed on the submission bound screen.

Test Type: Functional  
Components: PolicyCenter
Test Case Type: Positive
Product: Guidewire PolicyCenter
Platform: Web
Sprint: 1
Priority: High

Test Case ID/ Issue ID: TC-002
Summary: Verify the user cannot create a new submission with invalid credentials in the policycenter.
Acceptance Criteria ID: AC01
Labels: Smoke, Functional, Regression
Description: The user should not be able to create a new submission in the policycenter application with invalid credentials.
Prerequisites: The user has invalid login credentials.
Steps:
    Step-1
    Action: When the user navigates to the PolicyCenter application URL.
    Data: URL: http://in-pnq-coe31:5180/pc/PolicyCenter.do
    Expected Result: Then the login page is displayed.

    Step-2
    Action: When the user enters the invalid username and password.
    Data: Username: invalid, Password: invalid.
    Expected Result: Then the user is not logged in and an error message is displayed.

    Step-3
    Action: When the user tries to navigate to the 'New Submission' option from the Actions menu.
    Data: Submission: New Submission.
    Expected Result: Then the user is not able to access the submission page.

Test Type: Functional
Components: PolicyCenter
Test Case Type: Negative
Product: Guidewire PolicyCenter
Platform: Web
Sprint: 1
Priority: High


Test Case ID/ Issue ID: TC-003
Summary: Verify new submission with missing mandatory fields.
Acceptance Criteria ID: AC01
Labels: Smoke, Functional, Regression
Description: The user should not be able to create a new submission in the policycenter application with missing mandatory fields.
Prerequisites: The user has valid login credentials.
Steps:
    Step-1
    Action: When the user navigates to the PolicyCenter application URL.
    Data: URL: http://in-pnq-coe31:5180/pc/PolicyCenter.do
    Expected Result: Then the login page is displayed.

    Step-2
    Action: When the user enters the valid username and password.
    Data: Username: su, Password: gw.
    Expected Result: Then the user is logged in successfully.

    Step-3
    Action: When the user navigates to the 'New Submission' option from the Actions menu.
    Data: Submission: New Submission.
    Expected Result: Then the submission page is displayed.

    Step-4
    Action: When the user enters the required fields, selects the 'Base state', from the drop down list ,'Product- General Liability' from the list of products.
    Data:Base state: California, Product: General Liability
    Expected Result: Then the selected options are displayed and is directed to the offerings page.

    Step-5
    Action: When the user selects the 'offering - Special risk' and clicks on 'Next'.
    Data: Offering: Special risk.
    Expected Result: Then the offering is selected and the user is directed to the 'Qualification' screen.

    Step-6
    Action: When the User selects "Yes" or "No" for the qualification questions and clicks on next.
    Data: Yes/No
    Expected Result: Then the user is directed to the 'Policy info' screen.
    
    Step-7
    Action: When the user enters mandatory fields on the 'Policy info' screen like Data Quote needed and Estimated Premium.
    Data: 
        - Date Quote Needed: MM/dd/yyyy 
        - Estimated Premium: 
        - Primary Named Insured: January
        - Phone: 360-576-5672
        - Policy Address: 8902 NE 5th Ave, Vancouver, WA 98665
    Expected Result: Then the error message is displayed for missing fields.

    Step-8
    Action: When the user attempts to navigate to the exposure screen
    Data: -
    Expected Result: Then the user is not allowed to proceed without entering the mandatory fields.

Test Type: Functional
Components: PolicyCenter
Test Case Type: Negative
Product: Guidewire PolicyCenter
Platform: Web
Sprint: 1
Priority: High


Test Case ID/ Issue ID: TC-004
Summary: Verify new submission with invalid data in mandatory fields.
Acceptance Criteria ID: AC01
Labels: Smoke, Functional, Regression
Description: The user should not be able to create a new submission in the policycenter application with invalid data in mandatory fields.
Prerequisites: The user has valid login credentials.
Steps:
    Step-1
    Action: When the user navigates to the PolicyCenter application URL.
    Data: URL: http://in-pnq-coe31:5180/pc/PolicyCenter.do
    Expected Result: Then the login page is displayed.

    Step-2
    Action: When the user enters the valid username and password.
    Data: Username: su, Password: gw.
    Expected Result: Then the user is logged in successfully.

    Step-3
    Action: When the user navigates to the 'New Submission' option from the Actions menu.
    Data: Submission: New Submission.
    Expected Result: Then the 'New Submission' page is displayed.

    Step-4
    Action: When the user enters the required fields, selects the 'Base state', from the drop down list ,'Product- General Liability' from the list of products.
    Data:Base state: California, Product: General Liability
    Expected Result: Then the selected options are displayed and is directed to the offerings page.

    Step-5
    Action: When the user selects the 'offering - Special risk' and clicks on 'Next'.
    Data: Offering: Special risk.
    Expected Result: Then the offering is selected and the user is directed to the 'Qualification' screen.

    Step-6
    Action: When the User selects "Yes" or "No" for the qualification questions and clicks on next.
    Data: Yes/No
    Expected Result: Then the user is directed to the 'Policy info' screen.

    Step-7
    Action: When the user enters invalid data in mandatory fields on the 'Policy info' screen like Data Quote needed and Estimated Premium.
    Data: 
        - Date Quote Needed: Invalid date format
        - Estimated Premium: Invalid value
        - Primary Named Insured: 12345
        - Phone: Invalid phone number
        - Policy Address: Invalid address
    Expected Result: Then the error message is displayed for invalid data in mandatory fields.
    
    Step-8
    Action: When the user attempts to navigate to the exposure screen
    Data: -
    Expected Result: Then the user is not allowed to proceed with invalid data in mandatory fields.

Test Type: Functional
Components: PolicyCenter
Test Case Type: Negative
Product: Guidewire PolicyCenter
Platform: Web
Sprint: 1
Priority: High


Test Case ID/ Issue ID: TC-005
Summary: Verify new submission with valid data in all fields.
Acceptance Criteria ID: AC01
Labels: Smoke, Functional, Regression
Description: The user should be able to create a new submission in the policycenter application with valid data in all fields.
Prerequisites: The user has valid login credentials.
Steps:
    Step-1
    Action: When the user navigates to the PolicyCenter application URL.
    Data: URL: http://in-pnq-coe31:5180/pc/PolicyCenter.do
    Expected Result: Then the login page is displayed.

    Step-2
    Action: When the user enters the valid username and password.
    Data: Username: su, Password: gw.
    Expected Result: Then the user is logged in successfully.

    Step-3
    Action: When the user navigates to the 'New Submission' option from the Actions menu.
    Data: Submission: New Submission.
    Expected Result: Then the 'New Submission' page is displayed.

    Step-4
    Action: When the user enters the required fields, selects the 'Base state', from the drop down list ,'Product- General Liability' from the list of products.
    Data:Base state: California, Product: General Liability
    Expected Result: Then the selected options are displayed and is directed to the offerings page.

    Step-5
    Action: When the user selects the 'offering - Special risk' and clicks on 'Next'.
    Data: Offering: Special risk.
    Expected Result: Then the offering is selected and the user is directed to the 'Qualification' screen.

    Step-6
    Action: When the User selects "Yes" or "No" for the qualification questions and clicks on next.
    Data: Yes/No
    Expected Result: Then the user is directed to the 'Policy info' screen.

    Step-7
    Action: When the user enters valid data in all mandatory fields on the 'Policy info' screen.
    Data: 
        - Date Quote Needed: MM/dd/yyyy 
        - Estimated Premium: 
        - Primary Named Insured: January
        - Phone: 360-576-5672
        - Policy Address: 8902 NE 5th Ave, Vancouver, WA 98665
        - County: 
        - Address Type: Business
        - Address Description: 
        - Official IDs: 
        - FEIN: 
        - Industry Code: 
        - Business and Operations: 
        - Year Business Started: 
        - Description of business and operations: 
        - Organization Type: 
        - Additional Named Insureds: 
        - Name: 
        - Relationship to Primary Named Insured:
        - Industry Code:
        - Policy Details:

    Expected Result: Then the policy details are saved successfully.

    Step-8
    Action: When the user Navigates to the exposure screen
    Data: Exposure details
    Expected Result: Then the exposure screen is displayed.

    Step-9
    Action: When the user clicks on Add and enter location name, class code, Basis
    Data: Location Name: ABC, Class Code: 123, Basis: 456
    Expected Result: Then the premium is calculated and displayed on the quote screen.

    Step-10
    Action: When the user verifies Total premium, Taxes & Total cost
    Data: -
    Expected Result: Then premium, taxes, and total cost are displayed correctly.

    Step-11
    Action: When the user Clicks on Bind options and select Issue Policy and then click on OK
    Note: Any soft warning message - just ignore
    Data: -
    Expected Result: Then the policy is issued successfully and the confirmation message is displayed on the submission bound screen.

Test Type: Functional
Components: PolicyCenter
Test Case Type: Positive
Product: Guidewire PolicyCenter
Platform: Web
Sprint: 1
Priority: High


Test Case ID/ Issue ID: TC-006
Summary: View the summary of insured, coverages, and policy information before quoting.
Acceptance Criteria ID: AC02
Labels: Smoke, Functional, Regression
Description: The user should be able to view the summary of insured, coverages, and policy information before quoting.
Prerequisites: The user has valid login credentials.
Steps:
    Step-1
    Action: When the user navigates to the PolicyCenter application URL.
    Data: URL: http://in-pnq-coe31:5180/pc/PolicyCenter.do
    Expected Result: Then the login page is displayed.

    Step-2
    Action: When the user enters the valid username and password.
    Data: Username: su, Password: gw.
    Expected Result: Then the user is logged in successfully.

    Step-3
    Action: When the user navigates to the 'New Submission' option from the Actions menu.
    Data: Submission: New Submission.
    Expected Result: Then the 'New Submission' page is displayed.

    Step-4
    Action: When the user enters the required fields, selects the 'Base state', from the drop down list ,'Product- General Liability' from the list of products.
    Data:Base state: California, Product: General Liability
    Expected Result: Then the selected options are displayed and is directed to the offerings page.

    Step-5
    Action: When the user selects the 'offering - Special risk' and clicks on 'Next'.
    Data: Offering: Special risk.
    Expected Result: Then the offering is selected and the user is directed to the 'Qualification' screen.

    Step-6
    Action: When the User selects "Yes" or "No" for the qualification questions and clicks on next.
    Data: Yes/No
    Expected Result: Then the user is directed to the 'Policy info' screen.

    Step-7
    Action: When the user validates insured, coverages, and policy information.
    Data: -
    Expected Result: Then the insured, coverages, and policy information are displayed correctly.

Test Type: Functional
Components: PolicyCenter
Test Case Type: Positive
Product: Guidewire PolicyCenter
Platform: Web
Sprint: 1
Priority: High


Test Case ID/ Issue ID: TC-007
Summary: Creating a history event for policy issuance.
Acceptance Criteria ID: AC03
Labels: Smoke, Functional, Regression
Description: The history event should be created for policy issuance.
Prerequisites: The user has valid login credentials.
Steps:
    Step-1
    Action: When the user navigates to the PolicyCenter application URL.
    Data: URL: http://in-pnq-coe31:5180/pc/PolicyCenter.do
    Expected Result: Then the login page is displayed.

    Step-2
    Action: When the user enters the valid username and password.
    Data: Username: su, Password: gw.
    Expected Result: Then the user is logged in successfully.

    Step-3
    Action: When the user navigates to the 'New Submission' option from the Actions menu.
    Data: Submission: New Submission.
    Expected Result: Then the 'New Submission' page is displayed.

    Step-4
    Action: When the user enters the required fields, selects the 'Base state', from the drop down list ,'Product- General Liability' from the list of products.
    Data:Base state: California, Product: General Liability
    Expected Result: Then the selected options are displayed and is directed to the offerings page.

    Step-5
    Action: When the user selects the 'offering - Special risk' and clicks on 'Next'.
    Data: Offering: Special risk.
    Expected Result: Then the offering is selected and the user is directed to the 'Qualification' screen.

    Step-6
    Action: When the User selects "Yes" or "No" for the qualification questions and clicks on next.
    Data: Yes/No
    Expected Result: Then the user is directed to the 'Policy info' screen.

    Step-7
    Action: When the user enters mandatory fields on the 'Policy info' screen like Data Quote needed and Estimated Premium.
    Data: 
        - Date Quote Needed: MM/dd/yyyy 
        - Estimated Premium: 
        - Primary Named Insured: January
        - Phone: 360-576-5672
        - Policy Address: 8902 NE 5th Ave, Vancouver, WA 98665

    Expected Result: Then the policy details are saved successfully.

    Step-8
    Action: When the user Navigates to the exposure screen
    Data: Exposure details
    Expected Result: Then the exposure screen is displayed.

    Step-9
    Action: When the user clicks on Add and enter location name, class code, Basis
    Data: Location Name: ABC, Class Code: 123, Basis: 456
    Expected Result: Then the premium is calculated and displayed on the quote screen.

    Step-10
    Action: When the user verifies Total premium, Taxes & Total cost
    Data: -
    Expected Result: Then premium, taxes, and total cost are displayed correctly.

    Step-11
    Action: When the user Clicks on Bind options and select Issue Policy and then click on OK
    Note: Any soft warning message - just ignore
    Data: -
    Expected Result: Then the policy is issued successfully and the confirmation message is displayed on the submission bound screen.

    Step-12
    Action: When the user completes a policy issuance.
    Data: -
    Expected Result: Then the history event should be created for policy issuance.

Test Type: Functional
Components: PolicyCenter
Test Case Type: Positive
Product: Guidewire PolicyCenter
Platform: Web
Sprint: 1
Priority: High


Test Case ID/ Issue ID: TC-008
Summary: Verify the user can create a new submission in the policycenter with different product offerings.
Acceptance Criteria ID: AC01
Labels: Smoke, Functional, Regression
Description: The user should be able to create a new submission in the policycenter application with different product offerings.
Prerequisites: The user has valid login credentials.
Steps:
    Step-1
    Action: When the user navigates to the PolicyCenter application URL.
    Data: URL: http://in-pnq-coe31:5180/pc/PolicyCenter.do
    Expected Result: Then the login page is displayed.

    Step-2
    Action: When the user enters the valid username and password.
    Data: Username: su, Password: gw.
    Expected Result: Then the user is logged in successfully.

    Step-3
    Action: When the user navigates to the 'New Submission' option from the Actions menu.
    Data: Submission: New Submission.
    Expected Result: Then the 'New Submission' page is displayed.

    Step-4
    Action: When the user enters the required fields, selects the 'Base state', from the drop down list ,'Product- General Liability' from the list of products.
    Data:Base state: California, Product: General Liability
    Expected Result: Then the selected options are displayed and is directed to the offerings page.

    Step-5
    Action: When the user selects different product offerings like 'GL Standard'.
    Expected Result: Then the selected product offerings are displayed and the user can proceed with the submission.

Test Type: Functional
Components: PolicyCenter
Test Case Type: Positive
Product: Guidewire PolicyCenter
Platform: Web
Sprint: 1


Test Case ID/ Issue ID: TC-009
Summary: Verify the user can create a new submission in the policycenter with different base states.
Acceptance Criteria ID: AC01
Labels: Smoke, Functional, Regression
Description: The user should be able to create a new submission in the policycenter application with different base states.
Prerequisites: The user has valid login credentials.
Steps:
    Step-1
    Action: When the user navigates to the PolicyCenter application URL.
    Data: URL: http://in-pnq-coe31:5180/pc/PolicyCenter.do
    Expected Result: Then the login page is displayed.

    Step-2
    Action: When the user enters the valid username and password.
    Data: Username: su, Password: gw.
    Expected Result: Then the user is logged in successfully.

    Step-3
    Action: When the user navigates to the 'New Submission' option from the Actions menu.
    Data: Submission: New Submission.
    Expected Result: Then the 'New Submission' page is displayed.

    Step-4
    Action: When the user enters the required fields, selects different 'Base states' like 'Texas', 'Florida'.
    Data:Base state: Texas, Florida
    Expected Result: Then the selected base states are displayed and the user can proceed with the product selection.

Test Type: Functional
Components: PolicyCenter
Test Case Type: Positive
Product: Guidewire PolicyCenter
Platform: Web
Sprint: 1
Priority: High


Test Case ID/ Issue ID: TC-010
Summary: Verify the user can view the policy issuance history.
Acceptance Criteria ID: AC03
Labels: Smoke, Functional, Regression
Description: The user should be able to view the policy issuance history.
Prerequisites: The user has valid login credentials.

Steps:
    Step-1
    Action: When the user navigates to the PolicyCenter application URL.
    Data: URL: http://in-pnq-coe31:5180/pc/PolicyCenter.do
    Expected Result: Then the login page is displayed.

    Step-2
    Action: When the user enters the valid username and password.
    Data: Username: su, Password: gw.
    Expected Result: Then the user is logged in successfully.

    Step-3
    Action: When the user navigates to the 'Policy Issuance History' section.
    Data: -
    Expected Result: Then the policy issuance history is displayed.

Test Type: Functional
Components: PolicyCenter
Test Case Type: Positive
Product: Guidewire PolicyCenter
Platform: Web
Sprint: 1
Priority: High













  






        






       














